function getDom(id){
  return document.getElementById(id)
}

var todoStringField = getDom("inputString")
var todoList = getDom("todoList")
var deleteList = document.querySelectorAll('.delete')[0]

todoStringField.addEventListener('keyup', function(event){

  if(event.keyCode==13){
      var newtodo = todoStringField.value
      todoList.innerHTML += "<li>\
      <button class=\"delete\">o</button>\
      <input type=\"checkbox\" class=\"toggle-checked\">\
      <span class=\"text\">"+newtodo+"</span></li>"

      todoStringField.value = null;
  }
});

deleteList.addEventListener('click', function(target){
      console.log(target)
});
